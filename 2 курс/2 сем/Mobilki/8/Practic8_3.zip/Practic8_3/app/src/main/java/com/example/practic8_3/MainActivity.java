package com.example.practic8_3;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.squareup.picasso.Picasso;

import org.json.JSONObject;

import java.net.URL;
import java.util.Scanner;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private ImageView imageView;
    private Button loadButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageView = findViewById(R.id.imageView);
        loadButton = findViewById(R.id.loadButton);

        loadButton.setOnClickListener( v -> loadDogImage());
    }

    private void loadDogImage() {
        ExecutorService executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            try {
                URL url = new URL("https://random.dog/woof.json");
                Scanner scanner = new Scanner(url.openStream());
                StringBuilder result = new StringBuilder();
                while (scanner.hasNext()) {
                    result.append(scanner.nextLine());
                }
                scanner.close();

                JSONObject jsonObject = new JSONObject(result.toString());
                String imageUrl = jsonObject.getString("url");

                runOnUiThread(() -> {
                    Picasso.get().load(imageUrl).into(imageView);
                });
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}